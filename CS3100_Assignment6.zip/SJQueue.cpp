// #include "SJQueue.hpp"

// void SJQueue::pushTask(std::shared_ptr<Task> curTask)
// {
// 	queue.push(curTask);
// }

// std::shared_ptr<Task> SJQueue::pullTask()
// {
// 	std::shared_ptr<Task> toPull = queue.top();
// 	queue.pop();
// 	return toPull;
// }

// bool SJQueue::isEmpty()
// {
// 	std::cout << "Number of tasks in readyQueue: " << queue.size() << std::endl;
// 	// printQueue();
// 	if (queue.empty())
// 		return true;
// 	return false;
// }