// ready queue pseudocode

ReadyQueue::ReadyQueue()
{
	// set queue as a vector
}

ReadyQueue::pushTask(Task *curTask)
{
	// add task to queue
}

Task* ReadyQueue::pullTask()
{
	// pulls task item
	// returns task item
}