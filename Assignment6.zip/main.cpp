#include <iostream>
#include "Processor.hpp"

int main(void)
{
	Processor mainP;
	mainP.startShell();
	return 0;
}